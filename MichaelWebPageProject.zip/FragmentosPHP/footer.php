<!DOCTYPE html>
  <!-- Footer -->
  <link rel="stylesheet" href="css/footer-style.css">
  <footer>
    <!-- Footer Elements -->
    <div class="container-fluid">

      <!-- Grid row-->
      <div class="row">
        <div id="contenedor-iconos" class="col-12" >
         <a class="area-link" href="https://www.instagram.com/maikel.laudrup/"><img class="iconos" src="icons/insta_ico.svg" alt="instagram"></a>
         <a class="area-link" href="https://www.linkedin.com/in/michael-laudrup"><img class="iconos" src="icons/linkedin_ico.svg" alt="linkedin"></a>
         <a class="area-link" href="https://github.com/MichaeLaudrup"><img class="iconos" src="icons/github_ico.svg" alt="GitHub"></a>
         <a class="area-link" href="mailto:maikelaudrupluisgonzalez@gmail.com?Subject=Solicitud%20de%20información"><img class="iconos" src="icons/enviar_ico.svg" alt="Enviar mail"></a>
        </div>
      </div>
    <!-- Footer Elements -->
</div>
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3 " style="background-color: #343a40; color:white">© 2020 Copyright:
      <a href="https://MichaelaudrupluisGonzalez.es/" style="color:white">Autor: Michael Laudrup Luis Gonzalez</a>
    </div>
    <!-- Copyright -->

  </footer>
