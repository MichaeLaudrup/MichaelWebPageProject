<!DOCTYPE html>

	<link rel="stylesheet" href="css/header-style.css">
	<header>
    <!-- Area de navegacion -->
      <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
            <!-- Marca de la web -->
        <a id="brand-title" class="navbar-brand " href="index.php">Michael's PortFolio</a>
        <!-- Boton de menu desplegable en formato movil -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
       </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul id="lista" class="navbar-nav ">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">Inicio<span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#" >Academia</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Diseño Web</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#" >Melodías</a>
        </li>
        <li class="nav-item">
          <a target="_blank" class="nav-link" href="Documentos/CV_VersionWeb.pdf">MiCV</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#" >Contacto</a>
        </li>
        </ul>
      </div>
    </nav>
  </header>
