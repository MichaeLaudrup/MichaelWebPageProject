<link rel="stylesheet" href="css/mainPage-style.css">
<link rel="stylesheet" href="css/ResponsiveDesing.css">

<!-- Fragmento de texto -->
<!-- Este mensaje de bienvenida solo se muestra en pc, table... no movil-->



<div class="container-fluid">
	<div id="main-image" class="row rowImage">

	</div>
	<div class="row welcome-MobileMode onlyphone" >
		<h3>Bienvenido al portfolio de Michael</h3><br> En este espacio podrás conocerme mejor, aquí descrubiras cosas	increíbles que te permitirán apreciar que soy el candidato
	  perfecto para trabajar en tu compañia, es bien  sabido que la calidad exige tiempo, por ello, este espacio web esta en fase alpha de construcción.
	</div>

	<div id="First-imageRow" class="onlyphone row rowImage">
	</div>

	<div class="row">
		<div id="DescripcionAcademia" class="col-12 description-box">
			<p class="descriptions">Cuando empezamos a explorar el mundo de desarrollo web, lo primero que se aprecia es que la cantidad de tecnologías existentes es abrumadora, el objetivo
			de academia, es poner un poco de orden, dandote información de alta calidad que te permita entender cuando debes usar unas u otras tecnologías.</p>
			 <div id="deslizableSuperiorAcademia" class="col-12">
					<p class="row-titles">Academia</p>
			</div>
		</div>
	</div>

	<div id= "Second-imageRow" class="row rowImage"  >
	</div>

	<!-- SECCION DE DESCROPCION DE WEB DESING CON DESLIZABLES -->
	<div class="row" >
		<div id="webDesing-description" class="col-12 description-box" >
		<p class="descriptions">En este espacio apreciaras como puedo ayudar a tu empresa descubriendo mi potencial creativo en el arte del diseño web, con un desarrollo full-stack (Front-end y Back-end)
		en modelos de negocio totalmente diversos.  </p>

	  <div id="full-slider" class="col-12">
			<div id="right-slider" class="sliding-half">
				<p  class="row-titles" >o web</p>
	    </div>
			<div id="left-slider" class="sliding-half" >
				<p class="row-titles" >Diseñ</p>
	    </div>
	  </div>
	</div>
  </div>

	<div id="Third-imageRow" class="row rowImage">
	</div>
  <div class="row" >
			<div id="DescripcionMelodias" class="col-12 description-box">
				 <p class="descriptions">Dicen que la música es el reflejo del alma, que mejor manera de mostrarse al mundo que mostrando tu música, en el rincón de melodías podrás escuchar ciertas composiciones musicales
				 que he realizado de manera informal y que tal vez puedan endulzar tus oídos.</p>
				 <div id="deslizableSuperiorMelodias" class="col-12">
	 					<p class="row-titles">Melodías</p>
	 			</div>
			</div>
  </div>
	</div>
